//
//  PJViewController.m
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/13.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import "PJAddPhotosView.h"
#import "PJViewController.h"
#import "PJAssetsLibraryController.h"

@interface PJViewController () <UIActionSheetDelegate, UITextViewDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate>

@property (nonatomic, weak) UIImageView *imageView;

@property (nonatomic, weak) UIButton *buttonSelect;

@property (nonatomic, weak) PJAddPhotosView *photosView;

@end

@implementation PJViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //1. 设置导航栏
    [self setNav];
    
    //2. 创建按钮
    [self createButton];
    
    //3. 创建图片按钮
    [self createPhoto];
    
    //4. 创建选择的图片
    [self createSelectPhoto];
    
//    NSMutableArray *arr = [NSMutableArray array];
//    
//    UIImage *image1 = [UIImage imageNamed:@"checkbox_pic2"];
//    UIImage *image2 = [UIImage imageNamed:@"ic_addpic"];
//    UIImage *image3 = [UIImage imageNamed:@"navigation-bar-back"];
//    
//    [arr addObject:image1];
//    [arr addObject:image2];
//    
//    NSLog(@"%ld", arr.count);
//    
//    if ([arr containsObject:image3]) {
//    
//        NSLog(@"有");
//    } else {
//    
//        NSLog(@"没有");
//    }
}

- (void)createPhoto {

    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake((WIDTH-100)/2, 80, 100, 100)];
    self.imageView = imageView;
    [self.view addSubview:imageView];
    
    imageView.backgroundColor = [UIColor lightTextColor];
}

- (void)createButton {
    
    UILabel *label  = [[UILabel alloc] initWithFrame:CGRectMake(0, 200, WIDTH, 20)];
    [self.view addSubview:label];
    
    label.text = @"点我拍照哦";
    label.textColor = [UIColor redColor];
    label.textAlignment = NSTextAlignmentCenter;
    
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(137, 230, 100, 100)];
    
    button.backgroundColor = [UIColor clearColor];
    [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    [button setImage:[UIImage imageNamed:@"timg"] forState:UIControlStateNormal];
    [button setImage:[UIImage imageNamed:@"timg"] forState:UIControlStateHighlighted];
    
    [self.view addSubview:button];
}

- (void)createSelectPhoto {

//    UIButton *buttonSelect = [[UIButton alloc] initWithFrame:CGRectMake(0, 350, 70, 70)];
//    [buttonSelect setImage:[UIImage imageNamed:@"ic_addpic"] forState:UIControlStateNormal];
//    self.buttonSelect = buttonSelect;
//    [self.view addSubview:buttonSelect];
//    
//    [buttonSelect addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    
//    PJComposePhotosView *photosView = [[PJComposePhotosView alloc] init];
//    photosView.width = self.textView.width;
//    photosView.height = 500;//随便写
//    photosView.y = 60;
//    [self.textView addSubview:photosView];
//    self.photosView = photosView;

    PJAddPhotosView *photosView = [[PJAddPhotosView alloc] init];
    [self.view addSubview:photosView];
    self.photosView = photosView;
    
    photosView.width = WIDTH;
    photosView.height = 80;
    photosView.y = 350;
    photosView.x = 0;
    
    photosView.backgroundColor = [UIColor orangeColor];
    
    photosView.delectImageBlock = ^(UIImage *image) {
    
        self.imageView.image = image;
    };
}

-(void)buttonClick:(UIButton *)btn {
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照", @"从手机相册选择", nil];
    [actionSheet showInView:[UIApplication sharedApplication].keyWindow];
}

#pragma mark - 拍照和照相
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    switch (buttonIndex) {
        case 0: //拍照
            
            [self openCamera];
            break;
        case 1: //选择照片
            
            [self openAlbum];
            break;
            
        case 2: //取消
            
            break;
            
        default:
            break;
    }
}

/**
 *  打开照相机
 */
- (void)openCamera
{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) return;
    
    UIImagePickerController *ipc = [[UIImagePickerController alloc] init];
    ipc.sourceType = UIImagePickerControllerSourceTypeCamera;
    ipc.delegate = self;
    [self presentViewController:ipc animated:YES completion:nil];
}

#pragma mark - UIImagePickerControllerDelegate
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    //    PJLog(@"%@", info);
    //打开照相机和相册的处理方法是一样的
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    
    //1. 取出选中的图片
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    
    //2. 给控件设置图片
//    self.imageView.image = image;
    
    [self.photosView addImage:image];
    
    PJGroupImagesHelper *helper = [PJGroupImagesHelper shareInstance];
    helper.count++;
}

/**
 *  打开相册
 */
- (void)openAlbum
{
    // 系统的
//    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) return;
//    
//    UIImagePickerController *ipc = [[UIImagePickerController alloc] init];
//    ipc.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
//    ipc.delegate = self;
//    [self presentViewController:ipc animated:YES completion:nil];
    
    // 自定义的
    PJAssetsLibraryController *libraryVc = [[PJAssetsLibraryController alloc] init];
    
    __weak typeof(self) weakSelf = self;
    libraryVc.imageShowViewBlock = ^(NSMutableArray *arr) {
    
        weakSelf.photosView.pic_urls = [arr copy];
    };
    
    [self.navigationController pushViewController:libraryVc animated:YES];
}

- (void)setNav {
    
    self.title = @"相册Demo";
    self.view.backgroundColor = kGlobalBg;
}

@end

