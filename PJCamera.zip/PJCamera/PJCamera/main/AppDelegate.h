//
//  AppDelegate.h
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/13.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

