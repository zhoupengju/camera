//
//  pictureModel.h
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/13.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import <AssetsLibrary/AssetsLibrary.h>

@interface pictureModel : NSObject

@property (nonatomic, assign) BOOL selectFlag;

@property (nonatomic, strong) UIImage *pictureIcon;

@end
