//
//  libraryModel.h
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/13.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface libraryModel : NSObject

@property (nonatomic, strong) UIImage *libraryIcon;

@property (nonatomic, copy) NSString *libraryName;

@property (nonatomic, copy) NSString *libraryPhotoCount;

@property (nonatomic, strong) NSURL *libraryGroupUrl;


@end
