//
//  pictureModel.m
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/13.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import "pictureModel.h"

@implementation pictureModel

@end
