//
//  PJGroupImagesCollectionCell.h
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/13.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PJGroupImagesCollectionCell : UICollectionViewCell

@property (nonatomic, strong) pictureModel *image;

@property (nonatomic, copy) NSString *strSelect;

@property (nonatomic, strong) pictureModel *model;

+(NSMutableArray *)getImages;

@end
