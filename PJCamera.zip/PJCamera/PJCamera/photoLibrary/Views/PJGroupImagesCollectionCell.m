//
//  PJGroupImagesCollectionCell.m
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/13.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import "PJGroupImagesCollectionCell.h"

@interface PJGroupImagesCollectionCell () <UIAlertViewDelegate>

@property (nonatomic, weak) UIImageView *imageView;

@property (nonatomic, weak) UIButton *buttonSelect;

@property (nonatomic, strong) NSMutableArray *arrayImages;

@end

@implementation PJGroupImagesCollectionCell

-(NSMutableArray *)arrayImages {

    if (!_arrayImages) {
    
        _arrayImages = [NSMutableArray array];
    }
    return _arrayImages;
}

-(instancetype)initWithFrame:(CGRect)frame {

    self = [super initWithFrame:frame];
    if (self) {
        
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:self.bounds];
        self.imageView = imageView;
        [self.contentView addSubview:imageView];
        
        imageView.backgroundColor = [UIColor clearColor];
        imageView.contentMode = UIViewContentModeScaleAspectFill;
        imageView.clipsToBounds = YES;
        
        UIButton *buttonSelect = [[UIButton alloc] initWithFrame:self.contentView.bounds];
        self.buttonSelect = buttonSelect;
        [self.contentView addSubview:buttonSelect];
        
        buttonSelect.userInteractionEnabled = NO;
        [buttonSelect setImage:[UIImage imageNamed:@"checkbox_pic2"] forState:UIControlStateSelected];
    }
    return self;
}

-(void)setModel:(pictureModel *)model {

    _model = model;

//    static int count = 0;
//    NSLog(@"======%d", count);
    
//    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    for (UIView *btnSelect in self.contentView.subviews) {
        
        if ([btnSelect isKindOfClass:[UIButton class]]) {
            
            UIButton *btn = (UIButton *)btnSelect;
            
//            if (count > 4) {
//                
//                if (model.selectFlag) {
//                    
//                    model.selectFlag = !model.selectFlag;
//                    btn.selected = !btn.selected;
//                    count--;
//                    
//                    [self.arrayImages removeObject:model.pictureIcon];
//
//                    return;
//                }
//                
//                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"您最多只能选择5张图片" message:nil delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles:nil, nil];
//                [alertView show];
//                
//                return;
//            }
            
//            model.selectFlag = !model.selectFlag;
            btn.selected = !btn.selected;
            
//            NSMutableArray *arr = [NSMutableArray arrayWithArray:self.arrayImages];
            
//            [arr addObject:model.pictureIcon];
            
//            self.arrayImages = [arr mutableCopy];
            
            if (model.selectFlag) {
               
                btn.selected = YES;
//                count ++;
            } else {
                
                btn.selected = NO;
//                count--;
            }
        }
    }
    
    NSLog(@"%ld", self.arrayImages.count);
}

-(void)setImage:(pictureModel *)image {

    _image = image;
    
    self.imageView.image = image.pictureIcon;
    
    for (UIView *btnSelect in self.contentView.subviews) {
        
        if ([btnSelect isKindOfClass:[UIButton class]]) {
            
            UIButton *btn = (UIButton *)btnSelect;
            
            if (image.selectFlag) {
                
                btn.selected = YES;
            } else {
                
                btn.selected = NO;
            }
        }
    }
}

@end
