//
//  PJGroupImagesHelper.h
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/15.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PJGroupImagesHelper : NSObject

+ (id)shareInstance;

@property (nonatomic, assign) NSUInteger count;

@property (nonatomic, strong) NSMutableArray *arraySelectImage;

@end
