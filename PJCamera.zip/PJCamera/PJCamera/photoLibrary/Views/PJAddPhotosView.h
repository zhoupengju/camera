//
//  PJAddPhotosView.h
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/14.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PJAddPhotosView : UIView

// 添加一张图片
- (void)addImage:(UIImage *)image;

/** 添加一组图片 */
@property(nonatomic, strong)NSArray *pic_urls;

// 获取图片
- (NSArray *)images;

@property (nonatomic, copy) void (^delectImageBlock)(UIImage *image);

@end
