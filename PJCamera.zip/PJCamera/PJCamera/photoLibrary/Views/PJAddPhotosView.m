//
//  PJAddPhotosView.m
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/14.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import "PJAddPhotosView.h"

// 每行要显示图片的个数
#define numberPerRow 5

// 每个图片之间的间距
#define margin 8

// 每个图片的宽高
#define imageViewWH (self.width-margin*(numberPerRow+1))/numberPerRow

@implementation PJAddPhotosView

-(void)addImage:(UIImage *)image {

    UIImageView *imageView = [[UIImageView alloc] init];
    [self addSubview:imageView];
    
    imageView.image = image;
    imageView.clipsToBounds = YES;
    imageView.contentMode = UIViewContentModeScaleAspectFill;
    
    imageView.layer.cornerRadius = 5;
    imageView.layer.masksToBounds = YES;
    imageView.userInteractionEnabled = YES;
    
    UIButton *btnClose = [[UIButton alloc] init];
    [imageView addSubview:btnClose];
    
    btnClose.layer.cornerRadius = 5;
    btnClose.layer.masksToBounds = YES;
    btnClose.userInteractionEnabled = YES;
    [btnClose setImage:[UIImage imageNamed:@"close"] forState:UIControlStateNormal];
    [btnClose addTarget:self action:@selector(btnClose:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)setPic_urls:(NSArray *)pic_urls {

    for (int i=0; i<pic_urls.count; i++) {
    
        [self addImage:pic_urls[i]];
    }
}

-(void)layoutSubviews {

    [super layoutSubviews];
    
    NSUInteger count = self.subviews.count;
    
    for (NSUInteger i=0; i<count; i++) {
    
        // 行号
        NSUInteger col = i%numberPerRow;

        UIImageView *imageView = self.subviews[i];
        imageView.width = imageViewWH;
        imageView.height = imageViewWH;
        imageView.y = 0;
        imageView.x = col*(imageViewWH+margin)+margin;

        UIButton *btn = [imageView.subviews lastObject];
        btn.x = imageView.width-20;
        btn.y = 0;
        btn.width = 20;
        btn.height = 20;
    }
}

-(NSArray *)images
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (UIImageView *imageView in self.subviews)
    {
        [array addObject:imageView.image];
    }
    return array;
}

- (void)btnClose:(UIButton *)btn {

    UIImageView *imageview = (UIImageView *)btn.superview;
    
    [imageview removeFromSuperview];
    
    PJGroupImagesHelper *helper = [PJGroupImagesHelper shareInstance];
    helper.count--;
    
    if (self.delectImageBlock) {
    
        self.delectImageBlock(imageview.image);
    }
}

@end
