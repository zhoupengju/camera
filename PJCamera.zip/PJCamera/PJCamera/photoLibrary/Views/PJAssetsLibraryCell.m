//
//  PJAssetsLibraryCell.m
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/13.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import "PJAssetsLibraryCell.h"

@interface PJAssetsLibraryCell ()

@property (nonatomic, weak) UIImageView *imageIcon;

@property (nonatomic, weak) UILabel *labelTitle;

@property (nonatomic, weak) UILabel *labelCount;

@property (nonatomic, weak) UIButton *buttonArrow;

@property (nonatomic, weak) UIView *viewLine;

@end

@implementation PJAssetsLibraryCell

+(instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *ID = @"PJAssetsLibraryCell";
    
    PJAssetsLibraryCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil){
        
        cell = [[PJAssetsLibraryCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    }
    return cell;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        //0. cell的设置
        self.backgroundColor = [UIColor whiteColor];

        //1. 相册默认的图片
        UIImageView *imageIcon = [[UIImageView alloc] init];
        self.imageIcon = imageIcon;
        [self.contentView addSubview:imageIcon];
        
        imageIcon.frame = CGRectMake(10, 10, 100, 68);
        
        //2. 相册的标题
        UILabel *labelTitle = [[UILabel alloc] init];
        self.labelTitle = labelTitle;
        [self.contentView addSubview:labelTitle];
        
        labelTitle.font = kTitleFont;
        labelTitle.textColor = [UIColor blackColor];
        labelTitle.frame = CGRectMake(120, 25, WIDTH-130, 18);
        
        //3. 相册中图片的个数
        UILabel *labelCount = [[UILabel alloc] init];
        self.labelCount = labelCount;
        [self.contentView addSubview:labelCount];
        
        labelCount.font = kTitleFont;
        labelCount.textColor = [UIColor blackColor];
        labelCount.frame = CGRectMake(120, 45, WIDTH-130, 18);
        
        UIButton *buttonArrow = [[UIButton alloc] initWithFrame:CGRectMake(WIDTH-40, 0, 40, 88)];
        self.buttonArrow = buttonArrow;
        [self.contentView addSubview:buttonArrow];
        
        buttonArrow.userInteractionEnabled = NO;
        
        //4. cell线
        UIView *viewLine = [[UIView alloc] init];
        self.viewLine = viewLine;
        [self.contentView addSubview:viewLine];
        
        viewLine.backgroundColor = PJColor(226, 226, 226);
        viewLine.frame = CGRectMake(0, 87.5, WIDTH, 0.5);
        
    }
    return self;
}

-(void)setDataArray:(NSDictionary *)dataArray {

    _dataArray = dataArray;
    
//    self.textLabel.text = @"hahahhaha";
    
    self.imageIcon.image = dataArray[@"libraryIcon"];
    
    self.labelTitle.text = dataArray[@"libraryName"];
    
    self.labelCount.text = dataArray[@"libraryPhotoCount"];
    
    [self.buttonArrow setImage:[UIImage imageNamed:@"icon_nest"] forState:UIControlStateNormal];
}

-(void)setModel:(libraryModel *)model {

    _model = model;
    
    self.imageIcon.image = model.libraryIcon;
    
    self.labelTitle.text = model.libraryName;
    
    self.labelCount.text = model.libraryPhotoCount;
    
    [self.buttonArrow setImage:[UIImage imageNamed:@"icon_nest"] forState:UIControlStateNormal];
}

@end
