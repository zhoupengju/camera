//
//  PJAssetsLibraryCell.h
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/13.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PJAssetsLibraryCell : UITableViewCell

+ (instancetype)cellWithTableView:(UITableView *)tableView;

@property (nonatomic, strong) NSDictionary *dataArray;

@property (nonatomic, strong) libraryModel *model;

@end
