//
//  PJGroupImagesHelper.m
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/15.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import "PJGroupImagesHelper.h"

static PJGroupImagesHelper *instance = nil;

@implementation PJGroupImagesHelper

+(id)shareInstance {

    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        
        instance = [[PJGroupImagesHelper alloc] init];
        instance.count = 0;
    });
    
    return instance;
}

-(NSMutableArray *)arraySelectImage {
    
    if (!_arraySelectImage) {
        
        self.arraySelectImage = [NSMutableArray array];
    }
    return _arraySelectImage;
}

@end
