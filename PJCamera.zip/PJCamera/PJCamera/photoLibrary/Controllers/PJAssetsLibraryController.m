
//  PJAssetsLibraryController.m
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/13.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import "PJAssetsLibraryCell.h"
#import "PJGroupImagesController.h"
#import "PJAssetsLibraryController.h"

@interface PJAssetsLibraryController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableview;

@property (nonatomic, strong) ALAssetsLibrary *assetsLibrary;

@property (nonatomic, strong) NSArray *arrayFrames;

@end

@implementation PJAssetsLibraryController

#pragma mark - 懒加载
-(UITableView *)tableview {

    if (!_tableview) {
    
        UITableView *tableview = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, WIDTH, HEIGHT) style:UITableViewStylePlain];
        self.tableview = tableview;
        
        tableview.delegate = self;
        tableview.dataSource = self;
        
        tableview.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableview;
}

#pragma mark - 生命周期函数
- (void)viewDidLoad {
    [super viewDidLoad];
    
    //1. 设置导航栏
    [self setNav];
    
    //2. 创建tableview
    [self setTableView];
    
    //3. 获取图片
    [self setAssetsLibrary];
}

- (void)setAssetsLibrary {

    self.assetsLibrary  = [ALAssetsLibrary sharedAssetsLibrary];
    
    NSMutableArray *arrayFrames = [NSMutableArray array];
    [self.assetsLibrary enumerateGroupsWithTypes:ALAssetsGroupAll usingBlock:^(ALAssetsGroup *group, BOOL *stop) {
        
        if (group) {
        
            [group setAssetsFilter:[ALAssetsFilter allPhotos]];
            
            NSUInteger photoNums = group.numberOfAssets;
            if (photoNums) {
            
                NSString* groupname = [group valueForProperty:ALAssetsGroupPropertyName];
                UIImage *posterImg = [UIImage imageWithCGImage:[group posterImage]];
                NSString *groupUrl = [group valueForProperty:ALAssetsGroupPropertyURL];
                
                libraryModel *model = [[libraryModel alloc] init];
                model.libraryIcon = posterImg;
                model.libraryName = groupname;
                model.libraryPhotoCount = [NSString stringWithFormat:@"%ld", photoNums];
                model.libraryGroupUrl = groupUrl;
                
                [arrayFrames addObject:model];
                
//                [arrayFrames addObject:@{@"libraryIcon":posterImg, @"libraryName":groupname, @"libraryPhotoCount":[NSString stringWithFormat:@"%ld", photoNums], @"libraryGroupUrl":groupUrl}];
            }
        } else {
        
            self.arrayFrames = [arrayFrames copy];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self.tableview reloadData];
            });
        }
        
    } failureBlock:^(NSError *error) {
        
        
    }];
}

- (void)setTableView {
    
    [self.view addSubview:self.tableview];
}

#pragma mark - 实现UITableView代理
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.arrayFrames.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    PJAssetsLibraryCell *cell = [PJAssetsLibraryCell cellWithTableView:tableView];
    
//    NSDictionary *dataDic = self.arrayFrames[indexPath.row];
//    cell.dataArray = dataDic;
    
    cell.model = self.arrayFrames[indexPath.row];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
//    NSDictionary *dict = self.arrayFrames[indexPath.row];
//    PJGroupImagesController *groupVc = [[PJGroupImagesController alloc] init];
//    groupVc.url = dict[@"libraryGroupUrl"];
    
    libraryModel *model = self.arrayFrames[indexPath.row];
    PJGroupImagesController *groupVc = [[PJGroupImagesController alloc] init];
    groupVc.url = model.libraryGroupUrl;
    
    groupVc.imageShowBlock = ^(NSMutableArray *arr){
    
        if (self.imageShowViewBlock) {
        
            self.imageShowViewBlock(arr);
        }
    };
    
    [self.navigationController pushViewController:groupVc animated:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 88;
}


- (void)setNav {
    
    self.view.backgroundColor = kGlobalBg;

    // 设置导航默认标题的颜色及字体大小
    self.navigationItem.title = @"相薄";
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: kGlobalGreenBg,
        NSFontAttributeName : [UIFont boldSystemFontOfSize:18]};
    
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:@selector(rightBtnClick)];
    self.navigationItem.rightBarButtonItem = rightItem;
    self.navigationItem.rightBarButtonItem.tintColor = [UIColor redColor];
}


- (void)rightBtnClick
{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
