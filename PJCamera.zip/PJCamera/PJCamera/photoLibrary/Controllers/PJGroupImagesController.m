//
//  PJGroupImagesController.m
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/13.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import "PJViewController.h"
#import "PJGroupImagesController.h"
#import "PJGroupImagesCollectionCell.h"

#define kDBLibraryColumnsNumber 3
#define ID @"PJGroupImagesCollectionCell"

@interface PJGroupImagesController () <UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>

@property (nonatomic, weak) UICollectionView *collectionView;

@property (nonatomic, strong) NSMutableArray *imgArray;

// 点击之后获取到的 UIImage 存储到数组里面, containsObject 判断 数组里面是否存在来添加和删除
// 判断数组的个数, 限制最大的个数, 判断数组里面的东西进行处理.
// 每次点击之后, 先判断数组, 再做后续的工作.
@property (nonatomic, strong) NSMutableArray *arraySelectImage;

@property (nonatomic, strong) ALAssetsLibrary *assetsLibrary;

@property (nonatomic, strong) PJGroupImagesHelper *helper;

@end

@implementation PJGroupImagesController

-(NSMutableArray *)arraySelectImage {

    if (!_arraySelectImage) {
    
        self.arraySelectImage = [NSMutableArray array];
    }
    return _arraySelectImage;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //1. 设置导航栏
    [self setNav];
    
    //2.
    [self makeUI];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidBecomeActive) name:@"appDidBecomeActive" object:nil];
    
    self.assetsLibrary = [ALAssetsLibrary sharedAssetsLibrary];
    
    [self getPhotoList];
}

-(void)viewWillAppear:(BOOL)animated {

    [super viewWillAppear:YES];
    
    PJGroupImagesHelper *helper = [PJGroupImagesHelper shareInstance];
    self.helper = helper;
    
    static BOOL firstAppear = YES;
    
    if (firstAppear) {
        
        firstAppear = !firstAppear;
        
        return;
    }
    
    [self getPhotoList];
}

- (void)appDidBecomeActive {
    
    if (self.view.window) {
    
        [self getPhotoList];
    }
}

- (void)getPhotoList {

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        __block NSMutableArray *tmpImgArray = [NSMutableArray array];
        [self.assetsLibrary groupForURL:_url resultBlock:^(ALAssetsGroup *group) {
            
            if (group) {
            
                if (group.numberOfAssets > 0) {
                
                    [group enumerateAssetsUsingBlock:^(ALAsset *result, NSUInteger index, BOOL *stop) {
                        
                        if (result) {
                        
                            if ([[result valueForProperty:ALAssetPropertyType] isEqualToString:ALAssetTypePhoto]) {
                                
                                if ([result defaultRepresentation]) {
                                    
                                    pictureModel *model = [[pictureModel alloc] init];
                                    model.pictureIcon = [UIImage imageWithCGImage:[result thumbnail]];
                                    model.selectFlag = NO;
                                  
                                    [tmpImgArray insertObject:model atIndex:0];
                                    
                                }
                                
                            }
                        } else {
                        
                            self.imgArray = [tmpImgArray copy];
                            
                            dispatch_async(dispatch_get_main_queue(), ^{
                                
                                [self.collectionView reloadData];
                            });
                        }
                    }];
                }
            }
        } failureBlock:^(NSError *error) {
            
            NSLog(@"访问相册失败");
        }];
    });
}

#pragma mark CollectionDelegate
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    
    return self.imgArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    PJGroupImagesCollectionCell *item = [collectionView dequeueReusableCellWithReuseIdentifier:ID forIndexPath:indexPath];
    
    item.image = _imgArray[indexPath.row];
    
    return item;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake((_collectionView.frame.size.width / kDBLibraryColumnsNumber) - 1.0f, (_collectionView.frame.size.width / kDBLibraryColumnsNumber) - 1.0f);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [collectionView deselectItemAtIndexPath:indexPath animated:YES];

    PJGroupImagesCollectionCell *item = (PJGroupImagesCollectionCell *)[collectionView cellForItemAtIndexPath:indexPath];
    
    pictureModel *model = _imgArray[indexPath.row];
    
     NSLog(@"1111======%ld", self.helper.count);
    
//    if ([self.arraySelectImage containsObject:model.pictureIcon]) {
//        
//        if (self.arraySelectImage.count) {
//        
//            [self.arraySelectImage removeObject:model.pictureIcon];
//        }
//    } else {
//        
//        if (self.arraySelectImage.count < 5) {
//        
//            [self.arraySelectImage addObject:model.pictureIcon];
//        } else {
//        
//            NSLog(@"222222======%ld", self.arraySelectImage.count);
//
//            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"您最多只能选择5张图片" message:nil delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles:nil, nil];
//            [alertView show];
//            
//            return;
//        }
//    }
    
    if ([self.arraySelectImage containsObject:model.pictureIcon]) {
        
        if (self.helper.count) {
            
            [self.arraySelectImage removeObject:model.pictureIcon];
            
            self.helper.count--;
        }
    } else {
        
        if (self.helper.count < 5) {
            
            [self.arraySelectImage addObject:model.pictureIcon];
            
            self.helper.count++;
            NSLog(@"self.helper.count======%ld", self.helper.count);
        } else {
            
            NSLog(@"222222======%ld", self.helper.count);
            
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"您最多只能选择5张图片" message:nil delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles:nil, nil];
            [alertView show];
            
            return;
        }
    }
    model.selectFlag = !model.selectFlag;

    item.model = model;
}

- (void)makeUI {
    
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    
    flowLayout.minimumLineSpacing = 1;
    flowLayout.minimumInteritemSpacing = 1;
    flowLayout.sectionInset = UIEdgeInsetsZero;
    flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;

    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, WIDTH, HEIGHT-80) collectionViewLayout:flowLayout];
    [self.view addSubview:collectionView];
    self.collectionView = collectionView;
    
    collectionView.backgroundColor = [UIColor whiteColor];
    
    collectionView.delegate=self;
    collectionView.dataSource=self;
    
    
    [collectionView registerClass:[PJGroupImagesCollectionCell class] forCellWithReuseIdentifier:ID];
    
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, HEIGHT-80, WIDTH, 80)];
    [self.view addSubview:button];
    
    button.backgroundColor = kGlobalGreenBg;
    [button setTitle:@"确定" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(submitImages:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)submitImages:(UIButton *)btn {
    
    NSLog(@"submitImages= %ld", self.arraySelectImage.count);
    
    __weak typeof(self) weakSelf = self;
    if (self.imageShowBlock) {
    
        weakSelf.imageShowBlock(weakSelf.arraySelectImage);
    }
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}

-(void)setUrl:(NSURL *)url {

    _url = url;
}

- (void)setNav {
    
    self.view.backgroundColor = kGlobalBg;
    
    // 设置导航默认标题的颜色及字体大小
    self.navigationItem.title = @"相薄";
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: kGlobalGreenBg,
                                                                    NSFontAttributeName : [UIFont boldSystemFontOfSize:18]};
    
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:@selector(rightBtnClick)];
    self.navigationItem.rightBarButtonItem = rightItem;
    self.navigationItem.rightBarButtonItem.tintColor = [UIColor redColor];
    
    UIButton *btn = [[UIButton alloc] init];

    [btn setTitle:@"相薄" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont  boldSystemFontOfSize:16];
    [btn setImage:[UIImage imageNamed:@"navigation-bar-back"] forState:UIControlStateNormal];

    btn.size = CGSizeMake(60, 44);
    btn.imageEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
    btn.contentEdgeInsets = UIEdgeInsetsMake(0, -7, 0, 0);

    [btn addTarget:self action:@selector(leftBtnClick) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
}

- (void)leftBtnClick {

    [self.navigationController popViewControllerAnimated:YES];
}

- (void)rightBtnClick
{
    
    NSArray *array = self.navigationController.viewControllers;
    for (UIViewController *vc in array) {
    
        if ([vc isKindOfClass:[PJViewController class]]) {
        
            [self.navigationController popToViewController:vc animated:YES];
        }
    }
}

@end
