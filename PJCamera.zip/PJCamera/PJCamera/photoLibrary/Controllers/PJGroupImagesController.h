//
//  PJGroupImagesController.h
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/13.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PJGroupImagesController : UIViewController

@property (nonatomic, strong) NSURL *url;

@property (nonatomic, copy) void (^imageShowBlock)(NSMutableArray *arr);

@end
