//
//  ALAssetsLibrary+defaultAssetsLibrary.m
//  PJCamera
//
//  Created by 周鹏钜 on 16/6/13.
//  Copyright © 2016年 周鹏钜. All rights reserved.
//

#import "ALAssetsLibrary+defaultAssetsLibrary.h"

@implementation ALAssetsLibrary (defaultAssetsLibrary)

+(instancetype)sharedAssetsLibrary {

    static dispatch_once_t once;
    static ALAssetsLibrary *library = nil;
    
    dispatch_once(&once, ^{
        
        library = [[self alloc] init];
    });
    
    return library;
}

@end
